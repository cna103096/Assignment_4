﻿namespace Assignment_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Graph_Field = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.NumUpDown_XMin = new System.Windows.Forms.NumericUpDown();
            this.NumUpDown_XMax = new System.Windows.Forms.NumericUpDown();
            this.NumUpDown_XInterval = new System.Windows.Forms.NumericUpDown();
            this.NumUpDown_YInterval = new System.Windows.Forms.NumericUpDown();
            this.NumUpDown_YMax = new System.Windows.Forms.NumericUpDown();
            this.NumUpDown_YMin = new System.Windows.Forms.NumericUpDown();
            this.Button_Scale_Set = new System.Windows.Forms.Button();
            this.Button_Scale_Reset = new System.Windows.Forms.Button();
            this.RadioButton_Function1 = new System.Windows.Forms.RadioButton();
            this.RadioButton_Function2 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Button_Color_4 = new System.Windows.Forms.Button();
            this.Button_Color_3 = new System.Windows.Forms.Button();
            this.Button_Color_2 = new System.Windows.Forms.Button();
            this.Button_Color_1 = new System.Windows.Forms.Button();
            this.RadioButton_Function4 = new System.Windows.Forms.RadioButton();
            this.RadioButton_Function3 = new System.Windows.Forms.RadioButton();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.label8 = new System.Windows.Forms.Label();
            this.Textbox_Linear_M = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Textbox_Quadratic_A = new System.Windows.Forms.TextBox();
            this.Textbox_Cubic_A = new System.Windows.Forms.TextBox();
            this.Textbox_Circle_H = new System.Windows.Forms.TextBox();
            this.Textbox_Circle_K = new System.Windows.Forms.TextBox();
            this.Textbox_Cubic_B = new System.Windows.Forms.TextBox();
            this.Textbox_Quadratic_B = new System.Windows.Forms.TextBox();
            this.Textbox_Linear_B = new System.Windows.Forms.TextBox();
            this.Textbox_Circle_R = new System.Windows.Forms.TextBox();
            this.Textbox_Cubic_C = new System.Windows.Forms.TextBox();
            this.Textbox_Quadratic_C = new System.Windows.Forms.TextBox();
            this.Textbox_Cubic_D = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RadioButton_Circle = new System.Windows.Forms.RadioButton();
            this.RadioButton_Cubic = new System.Windows.Forms.RadioButton();
            this.RadioButton_Linear = new System.Windows.Forms.RadioButton();
            this.RadioButton_Quadratic = new System.Windows.Forms.RadioButton();
            this.Button_Draw = new System.Windows.Forms.Button();
            this.Button_Clear_Selected = new System.Windows.Forms.Button();
            this.Button_Clear_All = new System.Windows.Forms.Button();
            this.Label_Function_1 = new System.Windows.Forms.Label();
            this.Label_Function_2 = new System.Windows.Forms.Label();
            this.Label_Function_3 = new System.Windows.Forms.Label();
            this.Label_Function_4 = new System.Windows.Forms.Label();
            this.Label_Scope_1 = new System.Windows.Forms.Label();
            this.Label_Scope_2 = new System.Windows.Forms.Label();
            this.Label_Scope_3 = new System.Windows.Forms.Label();
            this.Label_Scope_4 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Graph_Field)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YMin)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Graph_Field
            // 
            this.Graph_Field.BackColor = System.Drawing.SystemColors.Control;
            this.Graph_Field.Location = new System.Drawing.Point(13, 13);
            this.Graph_Field.Name = "Graph_Field";
            this.Graph_Field.Size = new System.Drawing.Size(600, 400);
            this.Graph_Field.TabIndex = 0;
            this.Graph_Field.TabStop = false;
            this.Graph_Field.Paint += new System.Windows.Forms.PaintEventHandler(this.Draw_Axis);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(12, 434);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Scale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(13, 496);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Min X:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(13, 471);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Max X:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(12, 521);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "X Interval:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(187, 521);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Y Interval:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(187, 471);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Max Y:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(187, 496);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Min Y:";
            // 
            // NumUpDown_XMin
            // 
            this.NumUpDown_XMin.Location = new System.Drawing.Point(94, 494);
            this.NumUpDown_XMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumUpDown_XMin.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.NumUpDown_XMin.Name = "NumUpDown_XMin";
            this.NumUpDown_XMin.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_XMin.TabIndex = 12;
            this.NumUpDown_XMin.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.NumUpDown_XMin.ValueChanged += new System.EventHandler(this.CheckNumUpDown);
            // 
            // NumUpDown_XMax
            // 
            this.NumUpDown_XMax.Location = new System.Drawing.Point(94, 469);
            this.NumUpDown_XMax.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumUpDown_XMax.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.NumUpDown_XMax.Name = "NumUpDown_XMax";
            this.NumUpDown_XMax.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_XMax.TabIndex = 13;
            this.NumUpDown_XMax.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumUpDown_XMax.ValueChanged += new System.EventHandler(this.CheckNumUpDown);
            // 
            // NumUpDown_XInterval
            // 
            this.NumUpDown_XInterval.Location = new System.Drawing.Point(94, 519);
            this.NumUpDown_XInterval.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumUpDown_XInterval.Name = "NumUpDown_XInterval";
            this.NumUpDown_XInterval.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_XInterval.TabIndex = 14;
            this.NumUpDown_XInterval.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // NumUpDown_YInterval
            // 
            this.NumUpDown_YInterval.Location = new System.Drawing.Point(262, 519);
            this.NumUpDown_YInterval.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumUpDown_YInterval.Name = "NumUpDown_YInterval";
            this.NumUpDown_YInterval.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_YInterval.TabIndex = 17;
            this.NumUpDown_YInterval.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // NumUpDown_YMax
            // 
            this.NumUpDown_YMax.Location = new System.Drawing.Point(261, 469);
            this.NumUpDown_YMax.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumUpDown_YMax.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.NumUpDown_YMax.Name = "NumUpDown_YMax";
            this.NumUpDown_YMax.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_YMax.TabIndex = 16;
            this.NumUpDown_YMax.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumUpDown_YMax.ValueChanged += new System.EventHandler(this.CheckNumUpDown);
            // 
            // NumUpDown_YMin
            // 
            this.NumUpDown_YMin.Location = new System.Drawing.Point(261, 494);
            this.NumUpDown_YMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumUpDown_YMin.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.NumUpDown_YMin.Name = "NumUpDown_YMin";
            this.NumUpDown_YMin.Size = new System.Drawing.Size(56, 20);
            this.NumUpDown_YMin.TabIndex = 15;
            this.NumUpDown_YMin.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.NumUpDown_YMin.ValueChanged += new System.EventHandler(this.CheckNumUpDown);
            // 
            // Button_Scale_Set
            // 
            this.Button_Scale_Set.Location = new System.Drawing.Point(348, 510);
            this.Button_Scale_Set.Name = "Button_Scale_Set";
            this.Button_Scale_Set.Size = new System.Drawing.Size(75, 23);
            this.Button_Scale_Set.TabIndex = 18;
            this.Button_Scale_Set.Text = "Set Scale";
            this.Button_Scale_Set.UseVisualStyleBackColor = true;
            this.Button_Scale_Set.Click += new System.EventHandler(this.SetScale);
            // 
            // Button_Scale_Reset
            // 
            this.Button_Scale_Reset.Location = new System.Drawing.Point(429, 510);
            this.Button_Scale_Reset.Name = "Button_Scale_Reset";
            this.Button_Scale_Reset.Size = new System.Drawing.Size(75, 23);
            this.Button_Scale_Reset.TabIndex = 19;
            this.Button_Scale_Reset.Text = "Reset";
            this.Button_Scale_Reset.UseVisualStyleBackColor = true;
            this.Button_Scale_Reset.Click += new System.EventHandler(this.ResetScale);
            // 
            // RadioButton_Function1
            // 
            this.RadioButton_Function1.AutoSize = true;
            this.RadioButton_Function1.Checked = true;
            this.RadioButton_Function1.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Function1.Location = new System.Drawing.Point(8, 33);
            this.RadioButton_Function1.Name = "RadioButton_Function1";
            this.RadioButton_Function1.Size = new System.Drawing.Size(31, 17);
            this.RadioButton_Function1.TabIndex = 0;
            this.RadioButton_Function1.TabStop = true;
            this.RadioButton_Function1.Text = "1";
            this.RadioButton_Function1.UseVisualStyleBackColor = true;
            // 
            // RadioButton_Function2
            // 
            this.RadioButton_Function2.AutoSize = true;
            this.RadioButton_Function2.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Function2.Location = new System.Drawing.Point(62, 33);
            this.RadioButton_Function2.Name = "RadioButton_Function2";
            this.RadioButton_Function2.Size = new System.Drawing.Size(31, 17);
            this.RadioButton_Function2.TabIndex = 1;
            this.RadioButton_Function2.Text = "2";
            this.RadioButton_Function2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Button_Color_4);
            this.panel1.Controls.Add(this.Button_Color_3);
            this.panel1.Controls.Add(this.Button_Color_2);
            this.panel1.Controls.Add(this.Button_Color_1);
            this.panel1.Controls.Add(this.RadioButton_Function4);
            this.panel1.Controls.Add(this.RadioButton_Function3);
            this.panel1.Controls.Add(this.RadioButton_Function1);
            this.panel1.Controls.Add(this.RadioButton_Function2);
            this.panel1.Location = new System.Drawing.Point(675, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 61);
            this.panel1.TabIndex = 20;
            // 
            // Button_Color_4
            // 
            this.Button_Color_4.BackColor = System.Drawing.Color.Red;
            this.Button_Color_4.Location = new System.Drawing.Point(191, 3);
            this.Button_Color_4.Name = "Button_Color_4";
            this.Button_Color_4.Size = new System.Drawing.Size(30, 24);
            this.Button_Color_4.TabIndex = 7;
            this.Button_Color_4.UseVisualStyleBackColor = false;
            this.Button_Color_4.Click += new System.EventHandler(this.Change_Color_Button_Click);
            // 
            // Button_Color_3
            // 
            this.Button_Color_3.BackColor = System.Drawing.Color.Red;
            this.Button_Color_3.Location = new System.Drawing.Point(125, 3);
            this.Button_Color_3.Name = "Button_Color_3";
            this.Button_Color_3.Size = new System.Drawing.Size(30, 24);
            this.Button_Color_3.TabIndex = 6;
            this.Button_Color_3.UseVisualStyleBackColor = false;
            this.Button_Color_3.Click += new System.EventHandler(this.Change_Color_Button_Click);
            // 
            // Button_Color_2
            // 
            this.Button_Color_2.BackColor = System.Drawing.Color.Red;
            this.Button_Color_2.Location = new System.Drawing.Point(62, 3);
            this.Button_Color_2.Name = "Button_Color_2";
            this.Button_Color_2.Size = new System.Drawing.Size(30, 24);
            this.Button_Color_2.TabIndex = 5;
            this.Button_Color_2.UseVisualStyleBackColor = false;
            this.Button_Color_2.Click += new System.EventHandler(this.Change_Color_Button_Click);
            // 
            // Button_Color_1
            // 
            this.Button_Color_1.BackColor = System.Drawing.Color.Red;
            this.Button_Color_1.Location = new System.Drawing.Point(4, 3);
            this.Button_Color_1.Name = "Button_Color_1";
            this.Button_Color_1.Size = new System.Drawing.Size(30, 24);
            this.Button_Color_1.TabIndex = 4;
            this.Button_Color_1.UseVisualStyleBackColor = false;
            this.Button_Color_1.Click += new System.EventHandler(this.Change_Color_Button_Click);
            // 
            // RadioButton_Function4
            // 
            this.RadioButton_Function4.AutoSize = true;
            this.RadioButton_Function4.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Function4.Location = new System.Drawing.Point(191, 33);
            this.RadioButton_Function4.Name = "RadioButton_Function4";
            this.RadioButton_Function4.Size = new System.Drawing.Size(31, 17);
            this.RadioButton_Function4.TabIndex = 3;
            this.RadioButton_Function4.Text = "4";
            this.RadioButton_Function4.UseVisualStyleBackColor = true;
            // 
            // RadioButton_Function3
            // 
            this.RadioButton_Function3.AutoSize = true;
            this.RadioButton_Function3.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Function3.Location = new System.Drawing.Point(125, 31);
            this.RadioButton_Function3.Name = "RadioButton_Function3";
            this.RadioButton_Function3.Size = new System.Drawing.Size(31, 17);
            this.RadioButton_Function3.TabIndex = 2;
            this.RadioButton_Function3.Text = "3";
            this.RadioButton_Function3.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(635, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 24);
            this.label8.TabIndex = 21;
            this.label8.Text = "Functions";
            // 
            // Textbox_Linear_M
            // 
            this.Textbox_Linear_M.Location = new System.Drawing.Point(726, 135);
            this.Textbox_Linear_M.Name = "Textbox_Linear_M";
            this.Textbox_Linear_M.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Linear_M.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(668, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 18);
            this.label9.TabIndex = 23;
            this.label9.Text = "Linear";
            // 
            // Textbox_Quadratic_A
            // 
            this.Textbox_Quadratic_A.Location = new System.Drawing.Point(726, 189);
            this.Textbox_Quadratic_A.Name = "Textbox_Quadratic_A";
            this.Textbox_Quadratic_A.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Quadratic_A.TabIndex = 25;
            // 
            // Textbox_Cubic_A
            // 
            this.Textbox_Cubic_A.Location = new System.Drawing.Point(726, 245);
            this.Textbox_Cubic_A.Name = "Textbox_Cubic_A";
            this.Textbox_Cubic_A.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Cubic_A.TabIndex = 28;
            // 
            // Textbox_Circle_H
            // 
            this.Textbox_Circle_H.Location = new System.Drawing.Point(730, 306);
            this.Textbox_Circle_H.Name = "Textbox_Circle_H";
            this.Textbox_Circle_H.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Circle_H.TabIndex = 32;
            this.toolTip1.SetToolTip(this.Textbox_Circle_H, "The X coordinate of the center of the circle");
            // 
            // Textbox_Circle_K
            // 
            this.Textbox_Circle_K.Location = new System.Drawing.Point(822, 306);
            this.Textbox_Circle_K.Name = "Textbox_Circle_K";
            this.Textbox_Circle_K.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Circle_K.TabIndex = 36;
            this.toolTip1.SetToolTip(this.Textbox_Circle_K, "The Y coordinate of the center of the circle");
            // 
            // Textbox_Cubic_B
            // 
            this.Textbox_Cubic_B.Location = new System.Drawing.Point(800, 245);
            this.Textbox_Cubic_B.Name = "Textbox_Cubic_B";
            this.Textbox_Cubic_B.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Cubic_B.TabIndex = 35;
            // 
            // Textbox_Quadratic_B
            // 
            this.Textbox_Quadratic_B.Location = new System.Drawing.Point(800, 189);
            this.Textbox_Quadratic_B.Name = "Textbox_Quadratic_B";
            this.Textbox_Quadratic_B.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Quadratic_B.TabIndex = 34;
            // 
            // Textbox_Linear_B
            // 
            this.Textbox_Linear_B.Location = new System.Drawing.Point(800, 135);
            this.Textbox_Linear_B.Name = "Textbox_Linear_B";
            this.Textbox_Linear_B.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Linear_B.TabIndex = 33;
            // 
            // Textbox_Circle_R
            // 
            this.Textbox_Circle_R.Location = new System.Drawing.Point(896, 306);
            this.Textbox_Circle_R.Name = "Textbox_Circle_R";
            this.Textbox_Circle_R.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Circle_R.TabIndex = 39;
            this.toolTip1.SetToolTip(this.Textbox_Circle_R, "The Radius of the circle");
            // 
            // Textbox_Cubic_C
            // 
            this.Textbox_Cubic_C.Location = new System.Drawing.Point(874, 245);
            this.Textbox_Cubic_C.Name = "Textbox_Cubic_C";
            this.Textbox_Cubic_C.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Cubic_C.TabIndex = 38;
            // 
            // Textbox_Quadratic_C
            // 
            this.Textbox_Quadratic_C.Location = new System.Drawing.Point(874, 189);
            this.Textbox_Quadratic_C.Name = "Textbox_Quadratic_C";
            this.Textbox_Quadratic_C.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Quadratic_C.TabIndex = 37;
            // 
            // Textbox_Cubic_D
            // 
            this.Textbox_Cubic_D.Location = new System.Drawing.Point(935, 245);
            this.Textbox_Cubic_D.Name = "Textbox_Cubic_D";
            this.Textbox_Cubic_D.Size = new System.Drawing.Size(34, 20);
            this.Textbox_Cubic_D.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(668, 165);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 18);
            this.label10.TabIndex = 41;
            this.label10.Text = "Quadratic";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(668, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 18);
            this.label11.TabIndex = 42;
            this.label11.Text = "Cubic";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(670, 283);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 18);
            this.label12.TabIndex = 43;
            this.label12.Text = "Circle";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(694, 139);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 16);
            this.label13.TabIndex = 44;
            this.label13.Text = "y = ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(766, 138);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 16);
            this.label14.TabIndex = 45;
            this.label14.Text = "x +";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(763, 193);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 15);
            this.label15.TabIndex = 46;
            this.label15.Text = "x^2 +";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(840, 248);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 13);
            this.label16.TabIndex = 47;
            this.label16.Text = "x^2 +";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(763, 248);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 15);
            this.label17.TabIndex = 48;
            this.label17.Text = "x^3 +";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.Control;
            this.label18.Location = new System.Drawing.Point(840, 192);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 16);
            this.label18.TabIndex = 49;
            this.label18.Text = "x +";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.Control;
            this.label19.Location = new System.Drawing.Point(911, 245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 16);
            this.label19.TabIndex = 50;
            this.label19.Text = "x +";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.Control;
            this.label20.Location = new System.Drawing.Point(694, 192);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 16);
            this.label20.TabIndex = 51;
            this.label20.Text = "y = ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.Control;
            this.label21.Location = new System.Drawing.Point(694, 248);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 16);
            this.label21.TabIndex = 52;
            this.label21.Text = "y = ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.Control;
            this.label22.Location = new System.Drawing.Point(694, 309);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 13);
            this.label22.TabIndex = 53;
            this.label22.Text = "( ( x - ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.Control;
            this.label23.Location = new System.Drawing.Point(765, 309);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 13);
            this.label23.TabIndex = 54;
            this.label23.Text = ")^2 + ( y -";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.Control;
            this.label24.Location = new System.Drawing.Point(858, 309);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 13);
            this.label24.TabIndex = 55;
            this.label24.Text = ")^2 = ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.Control;
            this.label25.Location = new System.Drawing.Point(932, 309);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 13);
            this.label25.TabIndex = 56;
            this.label25.Text = "^2 )";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RadioButton_Circle);
            this.panel2.Controls.Add(this.RadioButton_Cubic);
            this.panel2.Controls.Add(this.RadioButton_Linear);
            this.panel2.Controls.Add(this.RadioButton_Quadratic);
            this.panel2.Location = new System.Drawing.Point(639, 116);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(30, 226);
            this.panel2.TabIndex = 21;
            // 
            // RadioButton_Circle
            // 
            this.RadioButton_Circle.AutoSize = true;
            this.RadioButton_Circle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_Circle.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Circle.Location = new System.Drawing.Point(9, 170);
            this.RadioButton_Circle.Name = "RadioButton_Circle";
            this.RadioButton_Circle.Size = new System.Drawing.Size(14, 13);
            this.RadioButton_Circle.TabIndex = 3;
            this.RadioButton_Circle.UseVisualStyleBackColor = true;
            // 
            // RadioButton_Cubic
            // 
            this.RadioButton_Cubic.AutoSize = true;
            this.RadioButton_Cubic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_Cubic.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Cubic.Location = new System.Drawing.Point(9, 108);
            this.RadioButton_Cubic.Name = "RadioButton_Cubic";
            this.RadioButton_Cubic.Size = new System.Drawing.Size(14, 13);
            this.RadioButton_Cubic.TabIndex = 2;
            this.RadioButton_Cubic.UseVisualStyleBackColor = true;
            // 
            // RadioButton_Linear
            // 
            this.RadioButton_Linear.AutoSize = true;
            this.RadioButton_Linear.Checked = true;
            this.RadioButton_Linear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_Linear.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Linear.Location = new System.Drawing.Point(9, 1);
            this.RadioButton_Linear.Name = "RadioButton_Linear";
            this.RadioButton_Linear.Size = new System.Drawing.Size(14, 13);
            this.RadioButton_Linear.TabIndex = 0;
            this.RadioButton_Linear.TabStop = true;
            this.RadioButton_Linear.UseVisualStyleBackColor = true;
            // 
            // RadioButton_Quadratic
            // 
            this.RadioButton_Quadratic.AutoSize = true;
            this.RadioButton_Quadratic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_Quadratic.ForeColor = System.Drawing.SystemColors.Control;
            this.RadioButton_Quadratic.Location = new System.Drawing.Point(9, 52);
            this.RadioButton_Quadratic.Name = "RadioButton_Quadratic";
            this.RadioButton_Quadratic.Size = new System.Drawing.Size(14, 13);
            this.RadioButton_Quadratic.TabIndex = 1;
            this.RadioButton_Quadratic.UseVisualStyleBackColor = true;
            // 
            // Button_Draw
            // 
            this.Button_Draw.Location = new System.Drawing.Point(753, 377);
            this.Button_Draw.Name = "Button_Draw";
            this.Button_Draw.Size = new System.Drawing.Size(49, 23);
            this.Button_Draw.TabIndex = 57;
            this.Button_Draw.Text = "Draw";
            this.Button_Draw.UseVisualStyleBackColor = true;
            this.Button_Draw.Click += new System.EventHandler(this.Button_Draw_Click);
            // 
            // Button_Clear_Selected
            // 
            this.Button_Clear_Selected.Location = new System.Drawing.Point(808, 377);
            this.Button_Clear_Selected.Name = "Button_Clear_Selected";
            this.Button_Clear_Selected.Size = new System.Drawing.Size(90, 23);
            this.Button_Clear_Selected.TabIndex = 58;
            this.Button_Clear_Selected.Text = "Clear Selected";
            this.Button_Clear_Selected.UseVisualStyleBackColor = true;
            this.Button_Clear_Selected.Click += new System.EventHandler(this.Button_Clear_Selected_Click);
            // 
            // Button_Clear_All
            // 
            this.Button_Clear_All.Location = new System.Drawing.Point(900, 377);
            this.Button_Clear_All.Name = "Button_Clear_All";
            this.Button_Clear_All.Size = new System.Drawing.Size(75, 23);
            this.Button_Clear_All.TabIndex = 59;
            this.Button_Clear_All.Text = "Clear All";
            this.Button_Clear_All.UseVisualStyleBackColor = true;
            this.Button_Clear_All.Click += new System.EventHandler(this.Button_Clear_All_Click);
            // 
            // Label_Function_1
            // 
            this.Label_Function_1.AutoSize = true;
            this.Label_Function_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Function_1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Function_1.Location = new System.Drawing.Point(613, 434);
            this.Label_Function_1.Name = "Label_Function_1";
            this.Label_Function_1.Size = new System.Drawing.Size(0, 20);
            this.Label_Function_1.TabIndex = 60;
            // 
            // Label_Function_2
            // 
            this.Label_Function_2.AutoSize = true;
            this.Label_Function_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Function_2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Function_2.Location = new System.Drawing.Point(613, 464);
            this.Label_Function_2.Name = "Label_Function_2";
            this.Label_Function_2.Size = new System.Drawing.Size(0, 20);
            this.Label_Function_2.TabIndex = 61;
            // 
            // Label_Function_3
            // 
            this.Label_Function_3.AutoSize = true;
            this.Label_Function_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Function_3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Function_3.Location = new System.Drawing.Point(613, 494);
            this.Label_Function_3.Name = "Label_Function_3";
            this.Label_Function_3.Size = new System.Drawing.Size(0, 20);
            this.Label_Function_3.TabIndex = 62;
            // 
            // Label_Function_4
            // 
            this.Label_Function_4.AutoSize = true;
            this.Label_Function_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Function_4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Function_4.Location = new System.Drawing.Point(613, 524);
            this.Label_Function_4.Name = "Label_Function_4";
            this.Label_Function_4.Size = new System.Drawing.Size(0, 20);
            this.Label_Function_4.TabIndex = 63;
            // 
            // Label_Scope_1
            // 
            this.Label_Scope_1.AutoSize = true;
            this.Label_Scope_1.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Scope_1.Location = new System.Drawing.Point(537, 439);
            this.Label_Scope_1.Name = "Label_Scope_1";
            this.Label_Scope_1.Size = new System.Drawing.Size(0, 13);
            this.Label_Scope_1.TabIndex = 64;
            // 
            // Label_Scope_2
            // 
            this.Label_Scope_2.AutoSize = true;
            this.Label_Scope_2.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Scope_2.Location = new System.Drawing.Point(537, 469);
            this.Label_Scope_2.Name = "Label_Scope_2";
            this.Label_Scope_2.Size = new System.Drawing.Size(0, 13);
            this.Label_Scope_2.TabIndex = 65;
            // 
            // Label_Scope_3
            // 
            this.Label_Scope_3.AutoSize = true;
            this.Label_Scope_3.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Scope_3.Location = new System.Drawing.Point(537, 499);
            this.Label_Scope_3.Name = "Label_Scope_3";
            this.Label_Scope_3.Size = new System.Drawing.Size(0, 13);
            this.Label_Scope_3.TabIndex = 66;
            // 
            // Label_Scope_4
            // 
            this.Label_Scope_4.AutoSize = true;
            this.Label_Scope_4.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Scope_4.Location = new System.Drawing.Point(537, 529);
            this.Label_Scope_4.Name = "Label_Scope_4";
            this.Label_Scope_4.Size = new System.Drawing.Size(0, 13);
            this.Label_Scope_4.TabIndex = 67;

            toolTip1.SetToolTip(Textbox_Linear_B, "Y intercept of the function");
            toolTip1.SetToolTip(Textbox_Linear_M, "Slope of the function");
            toolTip1.SetToolTip(Textbox_Quadratic_A, "Affects the width of the function");
            toolTip1.SetToolTip(Textbox_Quadratic_B, "Shifts axis of symmetry of the function");
            toolTip1.SetToolTip(Textbox_Quadratic_C, "Y intercept of the function");
            toolTip1.SetToolTip(Textbox_Cubic_A, "Affects the width of the function");
            toolTip1.SetToolTip(Textbox_Cubic_B, "Affects the width of the function");
            toolTip1.SetToolTip(Textbox_Cubic_C, "Shifts axis of symmetry of the function");
            toolTip1.SetToolTip(Textbox_Cubic_D, "Y Intercept of the parabola");

            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.Label_Scope_4);
            this.Controls.Add(this.Label_Scope_3);
            this.Controls.Add(this.Label_Scope_2);
            this.Controls.Add(this.Label_Scope_1);
            this.Controls.Add(this.Label_Function_4);
            this.Controls.Add(this.Label_Function_3);
            this.Controls.Add(this.Label_Function_2);
            this.Controls.Add(this.Label_Function_1);
            this.Controls.Add(this.Button_Clear_All);
            this.Controls.Add(this.Button_Clear_Selected);
            this.Controls.Add(this.Button_Draw);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Textbox_Cubic_D);
            this.Controls.Add(this.Textbox_Circle_R);
            this.Controls.Add(this.Textbox_Cubic_C);
            this.Controls.Add(this.Textbox_Quadratic_C);
            this.Controls.Add(this.Textbox_Circle_K);
            this.Controls.Add(this.Textbox_Cubic_B);
            this.Controls.Add(this.Textbox_Quadratic_B);
            this.Controls.Add(this.Textbox_Linear_B);
            this.Controls.Add(this.Textbox_Circle_H);
            this.Controls.Add(this.Textbox_Cubic_A);
            this.Controls.Add(this.Textbox_Quadratic_A);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Textbox_Linear_M);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Button_Scale_Reset);
            this.Controls.Add(this.Button_Scale_Set);
            this.Controls.Add(this.NumUpDown_YInterval);
            this.Controls.Add(this.NumUpDown_YMax);
            this.Controls.Add(this.NumUpDown_YMin);
            this.Controls.Add(this.NumUpDown_XInterval);
            this.Controls.Add(this.NumUpDown_XMax);
            this.Controls.Add(this.NumUpDown_XMin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Graph_Field);
            this.Name = "Form1";
            this.Text = "Assignment 4: Graphing Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.Graph_Field)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_XInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown_YMin)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Graph_Field;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown NumUpDown_XMin;
        private System.Windows.Forms.NumericUpDown NumUpDown_XMax;
        private System.Windows.Forms.NumericUpDown NumUpDown_XInterval;
        private System.Windows.Forms.NumericUpDown NumUpDown_YInterval;
        private System.Windows.Forms.NumericUpDown NumUpDown_YMax;
        private System.Windows.Forms.NumericUpDown NumUpDown_YMin;
        private System.Windows.Forms.Button Button_Scale_Set;
        private System.Windows.Forms.Button Button_Scale_Reset;
        private System.Windows.Forms.RadioButton RadioButton_Function1;
        private System.Windows.Forms.RadioButton RadioButton_Function2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RadioButton_Function4;
        private System.Windows.Forms.RadioButton RadioButton_Function3;
        private System.Windows.Forms.Button Button_Color_1;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button Button_Color_4;
        private System.Windows.Forms.Button Button_Color_3;
        private System.Windows.Forms.Button Button_Color_2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Textbox_Linear_M;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Textbox_Quadratic_A;
        private System.Windows.Forms.TextBox Textbox_Cubic_A;
        private System.Windows.Forms.TextBox Textbox_Circle_H;
        private System.Windows.Forms.TextBox Textbox_Circle_K;
        private System.Windows.Forms.TextBox Textbox_Cubic_B;
        private System.Windows.Forms.TextBox Textbox_Quadratic_B;
        private System.Windows.Forms.TextBox Textbox_Linear_B;
        private System.Windows.Forms.TextBox Textbox_Circle_R;
        private System.Windows.Forms.TextBox Textbox_Cubic_C;
        private System.Windows.Forms.TextBox Textbox_Quadratic_C;
        private System.Windows.Forms.TextBox Textbox_Cubic_D;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton RadioButton_Circle;
        private System.Windows.Forms.RadioButton RadioButton_Cubic;
        private System.Windows.Forms.RadioButton RadioButton_Linear;
        private System.Windows.Forms.RadioButton RadioButton_Quadratic;
        private System.Windows.Forms.Button Button_Draw;
        private System.Windows.Forms.Button Button_Clear_Selected;
        private System.Windows.Forms.Button Button_Clear_All;
        private System.Windows.Forms.Label Label_Function_1;
        private System.Windows.Forms.Label Label_Function_2;
        private System.Windows.Forms.Label Label_Function_3;
        private System.Windows.Forms.Label Label_Function_4;
        private System.Windows.Forms.Label Label_Scope_1;
        private System.Windows.Forms.Label Label_Scope_2;
        private System.Windows.Forms.Label Label_Scope_3;
        private System.Windows.Forms.Label Label_Scope_4;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

